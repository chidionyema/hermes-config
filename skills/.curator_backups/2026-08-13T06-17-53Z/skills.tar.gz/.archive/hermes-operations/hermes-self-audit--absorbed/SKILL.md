---
name: hermes-self-audit
description: Generate a complete audit of the Hermes setup — architecture, config, state, integrations, and task lifecycle.
---

# Hermes Self-Audit

## Trigger
Run this when the user asks "audit your setup", "document yourself", "how are you wired", or "show your configuration". Also run after significant config changes to update the audit.

## How to run

Execute each of the following commands and compile results into a single Markdown report. Do NOT describe from memory — inspect and report only what you find.

> **macOS note:** This Hermes instance runs as a LaunchAgent (`~/Library/LaunchAgents/ai.hermes.gateway.plist`). See `references/macos-launchd.md` for the plist details — use this instead of searching for systemd or cron entries.

### 1. Identity & Entrypoint

```bash
# Launchd service
launchctl list 2>/dev/null | grep -i hermes
cat ~/Library/LaunchAgents/*hermes*.plist
cat ~/Library/LaunchAgents/*ot-*.plist 2>/dev/null || echo "No otto launchd plists"

# Cron
cat ~/.hermes/cron/jobs.json | python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'{j[\"id\"][:12]}: {j.get(\"name\",\"?\")} | {j[\"schedule\"][\"display\"]} | enabled={j.get(\"enabled\",\"?\")}') for j in d.get('jobs',[])]"

# Shell config
grep -i 'hermes\|otto\|gateway' ~/.zshrc ~/.bashrc ~/.aliases 2>/dev/null || echo "No shell entries found"

# Running process
ps aux | grep -E '[h]ermes|[g]ateway' | head -5
```

### 2. Code Layout

```bash
find ~/.hermes -maxdepth 2 -not -path "*/node_modules/*" -not -path "*/.git/*" -not -path "*/__pycache__/*" -not -path "*/venv/*" -not -path "*/hermes-agent/hermes_cli/*" -not -path "*/hermes-agent/agent/*" -not -path "*/hermes-agent/apps/*" -not -path "*/hermes-agent/cron/*" -not -path "*/hermes-agent/assets/*" | sort
```

### 3. Dependencies & Runtime

```bash
~/.hermes/hermes-agent/venv/bin/python --version
node --version
dotnet --version 2>/dev/null || echo ".NET not verified"

# Key deps
grep -A 100 'dependencies = \[' ~/.hermes/hermes-agent/pyproject.toml | grep -m 20 '".*"'

# .env key names
grep -o '^[A-Z_]*=' ~/.hermes/.env | sed 's/=//' | sort -u
```

### 4. State & Memory

```bash
du -sh ~/.hermes/logs/
du -sh ~/.hermes/policies/
du -sh ~/.hermes/memories/
du -sh ~/.hermes/state.db*
wc -c ~/.hermes/memories/*.md
find ~/.hermes/policies -type f | wc -l
```

### 5. Integrations

```bash
cat ~/.hermes/gateway_state.json | python3 -m json.tool
cat ~/.hermes/channel_directory.json | python3 -m json.tool
cat ~/.hermes/auth.json | python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'{k}: {len(v)} entries') for k,v in d.get('credential_pool',{}).items()]"
```

### 6. Cron Jobs

```bash
# All jobs with metadata
cat ~/.hermes/cron/jobs.json | python3 -c "
import json,sys
d=json.load(sys.stdin)
for j in d.get('jobs',[]):
    status = j.get('last_status','never_run')
    errors = j.get('last_error','')
    runs = j.get('repeat',{}).get('completed',0)
    script = j.get('script','(agent-driven)')
    print(f\"{j['id'][:12]}: {j.get('name','?')} | {j['schedule']['display']} | enabled={j.get('enabled','?')} | status={status} | runs={runs} | script={script}\")
    if errors:
        print(f'  ⚠️  Error: {errors[:120]}')
"

# Cron health: flag jobs that have never run
echo "--- Cron Health Check ---"
cat ~/.hermes/cron/jobs.json | python3 -c "
import json,sys
d=json.load(sys.stdin)
never_run = [j for j in d.get('jobs',[]) if j.get('last_run_at') is None and j.get('last_status') is None]
errored = [j for j in d.get('jobs',[]) if j.get('last_status') == 'error']
print(f'Jobs never run: {len(never_run)}')
print(f'Jobs with errors: {len(errored)}')
for j in never_run:
    print(f'  ⏳ {j[\"id\"][:12]}: {j.get(\"name\",\"?\")} — scheduled {j[\"schedule\"][\"display\"]}')
for j in errored:
    print(f'  🔴 {j[\"id\"][:12]}: {j.get(\"name\",\"?\")} — {j.get(\"last_error\",\"?\")[:80]}')
"
```

### 7. Cron Script Operationality Check

For every cron job with `no_agent: true` and a `script` field, verify the script actually has an entry point:

```bash
cat ~/.hermes/cron/jobs.json | python3 -c "
import json, sys, os
d = json.load(sys.stdin)
for j in d.get('jobs', []):
    if j.get('no_agent') and j.get('script'):
        script_path = os.path.expanduser(f'~/.hermes/scripts/{j[\"script\"]}')
        if os.path.exists(script_path):
            with open(script_path) as f:
                content = f.read()
            has_main = 'if __name__' in content or content.strip().startswith('#!/')
            size = os.path.getsize(script_path)
            print(f'  {j[\"script\"]}: {\"✅\" if has_main else \"🔴 NO ENTRY POINT\"} ({size}b)')
        else:
            print(f'  {j[\"script\"]}: 🔴 FILE NOT FOUND')
"

### 8. Control Flow

Read these files and extract the message flow:
- `~/.hermes/hermes-agent/gateway/run.py` (first 100 lines for overview)
- `~/.hermes/hermes-agent/gateway/session.py` (class docstrings for session lifecycle)
- `~/.hermes/hermes-agent/run_agent.py` (first 50 lines for overview)
- `~/.hermes/hermes-agent/toolsets.py` (first 80 lines for tool list)

### 7. Verify all claims

Every statement should have a source file path or command output backing it.
Mark anything you **inferred** as `[INFERRED]` and anything you could NOT determine as an **Unknown**.

## 8. Operationalisation Check (Created vs. Running)

After creating any artifact (policy, script, cron, gate, tool, skill), verify it's **operational** — not just sitting on disk. The pattern that cost us 4 rounds of correction in one session is that created artifacts were never verified at creation time.

For each artifact, run the corresponding check in the **same turn**:

- **Script** → `python3 <script> --help` or run with test input
- **Cron job** → verify it appears in `jobs.json`, check `last_run_at` after next tick
- **Policy** → verify `firings_log` entry appears after a matching action
- **Dispatch gate** → `python3 dispatch_gate.py "should I do X"` → must return BLOCKED
- **Skill** → `skill_view(name)` → verify it loads without error
- **Config change** → re-read target file to verify the change persisted

When retro-auditing, for every item in the system ask: **does this have a runtime trigger, or is it just a file?** If it's just a file, it's not operational — fix that or delete it.

## Pitfalls

### Shell-escaped inline Python f-strings break silently (2026-06-21)
The audit skill's inline `python3 -c "..."` commands that use f-strings with emoji, colons, and curly braces inside shell quoting get mangled. Shell escaping eats the braces, producing `SyntaxError` or `NameError` with no useful error message. **The fix: use `execute_code` with native Python for any JSON processing that needs f-strings or special characters.** Move the `import json, sys, os` and the processing logic into `execute_code` — read files with `open()` and process in pure Python. Reserve inline `python3 -c` for simple one-liners with no special chars (e.g., `python3 -c "import json; print(len(json.load(open('x.json'))['jobs']))"`).

The specific failure mode: `cat jobs.json | python3 -c "print(f'{j[\"script\"]}: {\"OK\" if ...}')` — the `{` inside the f-string collides with shell brace expansion, and escaping them all is fragile. The execute_code path avoids the shell entirely.

### Use the venv, not anaconda3, when testing the gateway (2026-08-01)
The gateway ships via `~/.hermes/hermes-agent/venv/bin/python` (per the launchd plist). On macOS, `python` and `python3` typically resolve to anaconda3 (`/Users/chidionyema/anaconda3/bin/python`). If you run `python -m pytest ...` from a shell, pytest loads *that* interpreter — and anaconda3's pytest config may not have `pytest-asyncio` registered, even when the venv's pytest does. The failure mode: **all async tests collect and fail with `async def functions are not natively supported`, looking like a real gateway bug.**

The receipt for catching this: `PytestUnknownMarkWarning: Unknown pytest.mark.asyncio` in the warning summary, plus every async test failing for the same reason.

**The fix is one command and zero code changes:**
```bash
cd ~/.hermes/hermes-agent && ./venv/bin/python -m pytest tests/<path> -v --tb=short
```

**Verify the gateway's actual interpreter** before testing anything:
```bash
launchctl print gui/$(id -u)/ai.hermes.gateway | grep 'program ='
# → /Users/chidionyema/.hermes/hermes-agent/venv/bin/python
```

If `program` doesn't point at `venv/bin/python`, the live gateway is not what your tests cover. Either restart via launchctl or fix the plist.

### Test order matters — test the locked invariants first, not the broadest suite first (2026-08-01)
When auditing a UI overhaul (e.g. "gateway has had recent changes; how do I test"), the instinct is `pytest tests/gateway/operator_shell/` — but a broad suite call hides which contract is failing. **Test in dependency order:**
1. **Targeted invariant test first** — the test file the cockpit ships for the change you're checking (`test_cockpit_ia.py`, `test_find.py`, etc.). One file, fast, narrow.
2. **Related contracts** — other tests covering the same module family.
3. **Full suite** — only after each targeted file is green, to catch cross-cutting regressions.

For a 15-test-file suite, targeted-first is ~3s per file. Full suite still runs in <30s but you can't tell which contract the failure is in. **The pre-commit receipt is per-file green, not suite-green.**

### Inspect git first when the audit subject is "what changed" (2026-08-01)
Before reading changed files one-by-one, get the receipts in one pass:
```bash
cd <repo> && git log --oneline -15        # last 15 commits
cd <repo> && git diff --stat HEAD         # all unstaged + cumulative
cd <repo> && git diff --cached --stat     # staged-only (new files)
```
Then `grep -rn` for the broken affordance pattern across the diff. This produces the test plan in 60s, not 10 minutes of read-by-read.

For the 2026-08-01 cockpit overhaul: 23 commits + 22 unstaged + 4 staged files. The grep that surfaced the live defect (`6 "💰 Knobs" buttons link to dead `estate:se_params` return`) was one `grep -rn "se_params" gateway/operator_shell/`.

## Output format

Write to `~/.hermes/reports/hermes-setup-audit-YYYY-MM-DD.md` using this structure. See `~/.hermes/reports/comprehensive-audit-2026-06-18.md` for an example of the full output including issues found, recommendations, and git state.

```markdown
# Hermes Setup Audit — YYYY-MM-DD

> Methodology: Every claim below was verified by reading the actual file or running
> an actual command, unless marked [INFERRED].

## 1. Architecture (identity, entrypoint, code layout)
## 2. Dependencies & Runtime (language, packages, model config)
## 3. State & Memory (formats, sizes, locations)
## 4. Integrations (API keys by name, external services, platform wiring)
## 5. Cron Jobs (all active jobs, health, script entry-points)
## 6. Task Lifecycle (how a message becomes a response — trace the files)
## 7. Active Project Status (verified from disk)
## 8. Unknowns (explicitly list what you could NOT determine)
```

## Reference audits (use as templates)

For audits with a different focus than the audit script above, these reports demonstrate receipt-grade patterns:

- `~/.hermes/reports/cockpit-deep-audit-2026-08-01.md` — operator-cockpit deep audit (~610 lines). Code-evidenced (file:line citations) + session-evidenced (session_id:msg_id). Top-10 recommendations ranked by user-pain evidence, not by code discoverability. The template to copy when auditing UI surfaces, not the estate itself.
- `~/.hermes/reports/cockpit-friction-mining-2026-08-01.md` — companion friction-mining pass (~540 lines). Session-mined via `session_search`. Top-10 events, 5 recurring patterns, 5 verbatim quotes, 3 joy moments to preserve. The companion to any deep audit when the audit subject is a touchable surface.
